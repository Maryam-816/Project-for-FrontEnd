
document.addEventListener("DOMContentLoaded", function (e) {
    e.preventDefault()
    let cont =  document.createElement("div");
    cont.className = "container w-100 vh-50 d-flex justify-content-right align-items-right";
    let cont_time = document.createElement("section");
    cont_time.className = "time display-3";
    cont.appendChild(cont_time);
    document.body.appendChild(cont);

    setInterval(setTime, 1000);
   
    function setTime() {
        let date = new Date();
        date = date.toString();
        date = date.substr(16, 5);
        cont_time.innerHTML = date;
    }

    let photoProduct = {
        getAllPictures: function () {
            return images;
        }
    };

let imgManager = {
    showImageBox : function (image) {
        let img_box, picture, img_title, img_text;
        img_box = document.createElement("section");
        picture = document.createElement("img");
        img_title = document.createElement("h3");
        img_text = document.createElement("h6");

        img_box.className = "col-md-3 text-centre p-2 m-4 shadow h-75"; 

        picture.src = `./photos/${image.photo}`;
        picture.width = 50;
        picture.height = 50;

        img_title.innerHTML = `${image.title}`;

        img_text.innerHTML = `${image.text}`;

        img_box.appendChild(picture);
        img_box.appendChild(img_title);
        img_box.appendChild(img_text);

        return img_box;
    }
};
});


